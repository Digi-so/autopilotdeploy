
import React from 'react';
import { AgentType } from '../types';

interface AgentSelectorProps {
  currentAgent: AgentType;
  onAgentChange: (agent: AgentType) => void;
}

const AgentSelector: React.FC<AgentSelectorProps> = ({ currentAgent, onAgentChange }) => {
  const agentOptions = Object.values(AgentType).map(type => ({
    value: type,
    label: type.charAt(0).toUpperCase() + type.slice(1) // Capitalize first letter
  }));

  return (
    <div className="w-full">
      <label htmlFor="agent-type" className="block text-sm font-medium text-purple-200 mb-1">
        Select Agent Persona:
      </label>
      <select
        id="agent-type"
        value={currentAgent}
        onChange={(e) => onAgentChange(e.target.value as AgentType)}
        className="w-full p-3 bg-white/20 text-white rounded-lg focus:ring-2 focus:ring-purple-400 focus:outline-none appearance-none"
        style={{ 
          backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%23a855f7' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")`,
          backgroundPosition: 'right 0.5rem center',
          backgroundRepeat: 'no-repeat',
          backgroundSize: '1.5em 1.5em',
          paddingRight: '2.5rem'
        }}
      >
        {agentOptions.map(option => (
          <option key={option.value} value={option.value} className="bg-purple-700 text-white">
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
};

export default AgentSelector;
