
import React, { useEffect, useRef } from 'react';
import { Message } from '../types';

interface ChatDisplayProps {
  messages: Message[];
  isLoading: boolean;
}

const ChatDisplay: React.FC<ChatDisplayProps> = ({ messages, isLoading }) => {
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const TypingIndicator: React.FC = () => (
    <div className="flex items-center space-x-1 p-3 self-start">
      <div className="w-2 h-2 bg-purple-300 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
      <div className="w-2 h-2 bg-purple-300 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
      <div className="w-2 h-2 bg-purple-300 rounded-full animate-bounce"></div>
    </div>
  );

  return (
    <div className="flex-grow overflow-y-auto p-4 space-y-4 bg-black/20 rounded-xl shadow-inner mb-4 scrollbar-thin scrollbar-thumb-purple-400/70 scrollbar-track-transparent">
      {messages.map((msg) => (
        <div
          key={msg.id}
          className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
        >
          <div
            className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-3 rounded-2xl shadow-md break-words whitespace-pre-wrap ${
              msg.sender === 'user'
                ? 'bg-blue-500 text-white rounded-br-none'
                : 'bg-purple-500 text-white rounded-bl-none'
            }`}
          >
            {msg.sender === 'ai' && msg.agentType && (
              <p className="text-xs text-purple-200 mb-1 font-semibold capitalize">{msg.agentType} says:</p>
            )}
            {msg.text}
          </div>
        </div>
      ))}
      {isLoading && (
        <div className="flex justify-start">
            <div className="bg-purple-500 text-white rounded-2xl rounded-bl-none shadow-md">
                <TypingIndicator />
            </div>
        </div>
      )}
      <div ref={endOfMessagesRef} />
    </div>
  );
};

export default ChatDisplay;
