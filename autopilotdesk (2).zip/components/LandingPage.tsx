
import React from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { APP_NAME } from '../constants';

const LandingPage: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white">
      <header className="mb-12">
        <h1 className="text-6xl font-bold tracking-tight sm:text-7xl md:text-8xl">
          {APP_NAME}
        </h1>
        <p className="mt-6 text-xl text-purple-200 max-w-2xl">
          Your intelligent assistant platform. Leverage powerful AI agents for coaching, support, and administrative tasks.
        </p>
      </header>

      <section className="mb-12 max-w-3xl w-full">
        <h2 className="text-3xl font-semibold mb-6">Key Features</h2>
        <div className="grid md:grid-cols-3 gap-6 text-left">
          <div className="bg-white/10 backdrop-blur-md p-6 rounded-xl shadow-lg hover:bg-white/20 transition-all transform hover:scale-105">
            <h3 className="text-xl font-bold mb-2 text-purple-300">🤖 Versatile AI Agents</h3>
            <p className="text-purple-100">Choose from specialized agents like Business Coach, Tech Support, or Admin VA to get tailored assistance.</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-6 rounded-xl shadow-lg hover:bg-white/20 transition-all transform hover:scale-105">
            <h3 className="text-xl font-bold mb-2 text-purple-300">🗣️ Voice Input</h3>
            <p className="text-purple-100">Speak your prompts directly to the AI using advanced speech-to-text technology (browser permitting).</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-6 rounded-xl shadow-lg hover:bg-white/20 transition-all transform hover:scale-105">
            <h3 className="text-xl font-bold mb-2 text-purple-300">📜 Chat History</h3>
            <p className="text-purple-100">Keep track of your conversations with the AI during your current session for easy reference.</p>
          </div>
        </div>
      </section>

      <ReactRouterDOM.Link
        to="/dashboard"
        className="px-10 py-4 bg-purple-600 hover:bg-purple-500 text-white font-semibold rounded-lg shadow-md transition-all duration-300 ease-in-out text-lg transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:ring-opacity-75"
      >
        Ask an Agent Now
      </ReactRouterDOM.Link>
       <footer className="mt-16 text-purple-300 text-sm">
        <p>&copy; {new Date().getFullYear()} {APP_NAME}. All rights reserved.</p>
        <p>Powered by Google Gemini</p>
      </footer>
    </div>
  );
};

export default LandingPage;
