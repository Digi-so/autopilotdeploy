
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AgentType, Message } from '../types';
import { getAiReply } from '../services/geminiService';
import AgentSelector from './AgentSelector';
import ChatDisplay from './ChatDisplay';
import { APP_NAME } from '../constants';

// SpeechRecognition API might not be available on all browsers
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

const MicrophoneIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className || "w-6 h-6"}>
    <path d="M12 18.75a6 6 0 0 0 6-6v-1.5a6 6 0 0 0-12 0v1.5a6 6 0 0 0 6 6ZM12 2.25a4.5 4.5 0 0 0-4.5 4.5v1.5a4.5 4.5 0 0 0 9 0v-1.5a4.5 4.5 0 0 0-4.5-4.5Z" />
  </svg>
);

const SendIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className || "w-6 h-6"}>
    <path d="M3.478 2.404a.75.75 0 0 0-.926.941l2.432 7.905H13.5a.75.75 0 0 1 0 1.5H4.984l-2.432 7.905a.75.75 0 0 0 .926.94 60.519 60.519 0 0 0 18.445-8.986.75.75 0 0 0 0-1.218A60.517 60.517 0 0 0 3.478 2.404Z" />
  </svg>
);

const DashboardPage: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [agentType, setAgentType] = useState<AgentType>(AgentType.COACH);
  const [chatHistory, setChatHistory] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const speechRecognitionRef = useRef<any>(null);
  const [speechApiAvailable, setSpeechApiAvailable] = useState<boolean>(false);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      setSpeechApiAvailable(true);
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setPrompt(transcript);
        setIsRecording(false);
      };
      recognition.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        setError(`Speech recognition error: ${event.error}`);
        setIsRecording(false);
      };
      recognition.onend = () => {
        setIsRecording(false);
      };
      speechRecognitionRef.current = recognition;
    } else {
      setSpeechApiAvailable(false);
      console.warn('Speech Recognition API not available in this browser.');
    }
  }, []);

  const handleToggleRecording = useCallback(() => {
    if (!speechApiAvailable || !speechRecognitionRef.current) return;

    if (isRecording) {
      speechRecognitionRef.current.stop();
      setIsRecording(false);
    } else {
      // Request microphone permission (implicitly handled by browser)
      navigator.mediaDevices.getUserMedia({ audio: true })
        .then(() => {
            setPrompt(''); // Clear prompt before new recording
            speechRecognitionRef.current.start();
            setIsRecording(true);
            setError(null);
        })
        .catch(err => {
            console.error("Microphone access denied:", err);
            setError("Microphone access denied. Please enable microphone permissions in your browser settings.");
            setIsRecording(false);
        });
    }
  }, [isRecording, speechApiAvailable]);

  const handleSubmit = async () => {
    if (!prompt.trim()) return;

    const userMessage: Message = { id: Date.now().toString(), sender: 'user', text: prompt, agentType };
    setChatHistory(prev => [...prev, userMessage]);
    setIsLoading(true);
    setError(null);
    setPrompt('');

    try {
      const aiText = await getAiReply(prompt, agentType);
      const aiMessage: Message = { id: (Date.now() + 1).toString(), sender: 'ai', text: aiText, agentType };
      setChatHistory(prev => [...prev, aiMessage]);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(errorMessage);
      const errorAiMessage: Message = { id: (Date.now() + 1).toString(), sender: 'ai', text: `Sorry, I encountered an error: ${errorMessage}`, agentType };
      setChatHistory(prev => [...prev, errorAiMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col w-full max-w-3xl mx-auto h-screen p-4 md:p-6">
      <header className="mb-6 text-center">
        <h1 className="text-4xl font-bold tracking-tight">{APP_NAME} Dashboard</h1>
        <p className="text-purple-200">Select an agent and start your conversation.</p>
      </header>

      <ChatDisplay messages={chatHistory} isLoading={isLoading} />

      {error && <div className="my-2 p-3 bg-red-500/80 text-white rounded-md text-sm">{error}</div>}

      <div className="mt-auto p-4 bg-white/10 backdrop-blur-md rounded-xl shadow-xl">
        <div className="mb-3">
          <AgentSelector currentAgent={agentType} onAgentChange={setAgentType} />
        </div>
        <div className="flex items-center gap-2">
          <textarea
            rows={2}
            className="flex-grow p-3 bg-white/20 text-white placeholder-purple-300 rounded-lg focus:ring-2 focus:ring-purple-400 focus:outline-none resize-none scrollbar-thin scrollbar-thumb-purple-400 scrollbar-track-purple-200/50"
            placeholder={isRecording ? "Listening..." : `Ask ${agentType}...`}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit();
              }
            }}
            disabled={isLoading || isRecording}
          />
          {speechApiAvailable && (
            <button
              onClick={handleToggleRecording}
              className={`p-3 rounded-lg transition-colors ${isRecording ? 'bg-red-500 hover:bg-red-600 animate-pulse' : 'bg-purple-500 hover:bg-purple-600'} text-white disabled:opacity-50`}
              title={isRecording ? "Stop recording" : "Start voice input"}
              disabled={isLoading}
            >
              <MicrophoneIcon className="w-6 h-6" />
            </button>
          )}
          <button
            onClick={handleSubmit}
            className="p-3 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors disabled:opacity-50"
            disabled={isLoading || !prompt.trim()}
            title="Send message"
          >
            <SendIcon className="w-6 h-6" />
          </button>
        </div>
         {!speechApiAvailable && (
          <p className="text-xs text-purple-300 mt-2 text-center">Voice input is not available in your browser.</p>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;
