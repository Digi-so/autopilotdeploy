
import React from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import LandingPage from './components/LandingPage';
import DashboardPage from './components/DashboardPage';

const App: React.FC = () => {
  return (
    <ReactRouterDOM.HashRouter>
      <div className="min-h-screen text-white flex flex-col items-center w-full bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900">
        <ReactRouterDOM.Routes>
          <ReactRouterDOM.Route path="/" element={<LandingPage />} />
          <ReactRouterDOM.Route path="/dashboard" element={<DashboardPage />} />
          <ReactRouterDOM.Route path="*" element={<ReactRouterDOM.Navigate to="/" />} />
        </ReactRouterDOM.Routes>
      </div>
    </ReactRouterDOM.HashRouter>
  );
};

export default App;
