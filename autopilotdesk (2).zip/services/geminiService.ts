
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { AgentType } from '../types';
import { AGENT_SYSTEM_PROMPTS, GEMINI_MODEL_NAME } from '../constants';

// This assumes process.env.API_KEY is set in the environment where this script runs.
// In a purely client-side SPA without a build step, this would need to be handled differently (e.g., user input, which is outside current constraints).
// For this exercise, we proceed as if it's available.
const apiKey = process.env.API_KEY;

if (!apiKey) {
  console.warn(
    "API_KEY environment variable not found. AI features will not work. Please ensure API_KEY is set."
  );
}

const ai = new GoogleGenAI({ apiKey: apiKey || "NO_API_KEY_PROVIDED" });

export const getAiReply = async (prompt: string, agentType: AgentType): Promise<string> => {
  if (!apiKey) {
    return "API Key not configured. Please set the API_KEY environment variable.";
  }

  const systemInstruction = AGENT_SYSTEM_PROMPTS[agentType];

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        // Default thinking config (enabled) is generally good.
        // For very low latency, like a game AI, one might add:
        // thinkingConfig: { thinkingBudget: 0 } 
      },
    });
    return response.text;
  } catch (error) {
    console.error("Error getting AI reply:", error);
    if (error instanceof Error) {
        return `Error from AI: ${error.message}`;
    }
    return "An unexpected error occurred while contacting the AI.";
  }
};
