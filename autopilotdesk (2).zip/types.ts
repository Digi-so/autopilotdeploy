
export enum AgentType {
  COACH = "coach",
  SUPPORT = "support",
  ADMIN = "admin",
}

export interface Message {
  id: string;
  sender: "user" | "ai";
  text: string;
  agentType?: AgentType; 
}
